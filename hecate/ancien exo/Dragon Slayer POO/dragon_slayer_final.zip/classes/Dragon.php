<?php

require_once 'Monster.php';

class Dragon extends Monster{

    public function __construct($difficulty)
    {
        parent::__construct($difficulty);
        $this->name = 'dragon squellette';
    }

    public function presentation(){
        return 'Le monstre est un dragon squelette et il a '.$this->pv.' points de vie';
    }

}