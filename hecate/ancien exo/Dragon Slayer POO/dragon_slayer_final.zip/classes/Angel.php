<?php

require_once 'Player.php';

//extension de la classe abstraite
class Angel extends Player{

    private $type;

    public function __construct($name)
    {
        $this->type = 'ange';
        //appel du constructeur de la classe parente
        parent::__construct($name);
    }

    public function presentation(){
        return 'Le joueur s\'appel '.$this->name.' il est de type '.$this->type.' et il a '.$this->pv.' points de vie';
    }

    public function attack($adversaire){
        $alea = rand(0, 100);
        //l'attaque fatale n'as que 10% de chance d'etre lancé
        if($alea < 5){
            return $this->attackFatal($adversaire);
        }else{
            //appel de l'attque habituel (dans la classe parente)
            return parent::attack($adversaire);
        }
    }

    public function attackFatal($adversaire){
        $pv = $adversaire->getPv();
        $adversaire->setPv(0);

        return $this->name.' a lancé sont attaque ultime \'les étoiles\' et inflige les degats maximum ('.$pv.'pv)';
    }

}