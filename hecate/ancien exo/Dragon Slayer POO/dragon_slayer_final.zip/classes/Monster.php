<?php

abstract class Monster{

    protected $pv;
    protected $name;

    public function __construct($difficulty)
    {
        switch ($difficulty) {
            case 'difficile':
                $this->pv = rand(300, 400);
                break;
            case 'normal':
                $this->pv = rand(250, 300);
                break;
            case 'facile':
                $this->pv = rand(200, 250);
                break;
        }
        $this->name = '';
    }

    public function attack($adversaire){
        $pv = $adversaire->getPv();
        $pa = rand(20, 30);
        $pv = $pv - $pa;
        $adversaire->setPv($pv);

        return 'Le dragon attaque avec son souffle et inflige '.$pa.' point de degats';
    }

    public function getPv(){
        return $this->pv;
    }

    public function setPv($pv){
        $this->pv = $pv;
    }

}